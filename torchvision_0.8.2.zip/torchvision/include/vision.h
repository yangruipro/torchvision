#ifndef VISION_H
#define VISION_H

#include <torchvision/models/models.h>

#endif // VISION_H
