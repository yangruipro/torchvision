#pragma once

#if PNG_FOUND
#include <png.h>
#include <setjmp.h>
#endif
